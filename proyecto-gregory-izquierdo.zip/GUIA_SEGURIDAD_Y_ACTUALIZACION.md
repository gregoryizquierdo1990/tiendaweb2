# Guía Oficial de Seguridad, Protección contra Plagio y Paso a Paso para Actualizaciones
**Plataforma de Streaming & Servicios Digitales — Proyecto Gregori Izquierdo**

---

## 🛡️ PARTE 1: MEDIDAS DE SEGURIDAD INTEGRAL & PROTECCIÓN CONTRA PLAGIO Y ACCESOS NO DESEADOS

### 1. Control de Acceso Basado en Roles (RBAC) y Jerarquía Estricta
La plataforma utiliza un esquema estricto de roles para garantizar que sólo el personal autorizado tenga acceso a las funciones de nivel superior:
* **Super Administrador (Gregori Izquierdo):** Control total del catálogo, tasa BCV, credenciales de proveedores, Wallet GRPAY, reversos, configuraciones de marca y bitácora.
* **Franquiciados Pro / Vendedores:** Acceso restringido únicamente a su red de clientes asignados, consulta de comisiones e inventario sin permisos para alterar configuraciones globales o precios base.
* **Clientes:** Acceso limitado a su portal personal para consultar sus credenciales compradas, saldo Wallet y cronograma de cuotas.

### 2. Autenticación Restringida y Cambio de Contraseñas Maestras
* **Bitácora de Auditoría (Audit Log):** Toda modificación crítica (cambio de precios, reset de contraseñas, edición de tasa BCV, aprobación de saldo o devolución) queda registrada con marca de tiempo, usuario y dirección IP en la sección de **Bitácora**.
* **Reset de Contraseñas desde Admin:** Para evitar accesos no deseados o suplantación de identidad, los administradores pueden restablecer la contraseña de cualquier usuario cliente o franquiciado directamente desde el módulo **Usuarios Admin**.

### 3. Protección de Código Fuente e Propiedad Intelectual
* **Minificación y Ofuscación Automática:** Durante la compilación de producción (`npm run build`), el bundler elimina comentarios, comprime identificadores y liquida referencias al entorno de desarrollo.
* **Firmado de Dominio Oficial:** Todas las credenciales y avisos formateados por la plataforma incluyen automáticamente el dominio oficial verificado `https://gregoryizquierdo.xyz` (o el subdominio autorizado). Si el código es alojado en un dominio no autorizado, el sistema puede bloquear llamadas hacia Google Sheets o pasarelas mediante validación de origen (CORS).

### 4. Resguardo y Respaldos en Google Drive & Sheets
* **Sincronización en Tiempo Real:** Todos los pedidos, reportes de recargas Wallet y base de datos de clientes se respaldan de manera redundante en tus hojas de cálculo privadas de **Google Sheets**.
* **Restauración en caso de desastre:** Si se detecta un intento de alteración o acceso no autorizado, puedes revocar el acceso OAuth desde Google Security Center y restaurar los datos desde Google Sheets con 1 clic.

---

## 🚀 PARTE 2: GUÍA PASO A PASO PARA SUBIR ACTUALIZACIONES AL PROYECTO

### Paso 1: Preparación y Verificación del Código
Antes de desplegar cualquier actualización, ejecuta los siguientes comandos de verificación interna:
```bash
# 1. Comprobar que no existan errores de sintaxis o TypeScript
npm run lint

# 2. Compilar el proyecto en modo producción
npm run build
```

### Paso 2: Generación del Paquete de Actualización (.ZIP)
Para empaquetar la versión más reciente del sistema para distribución o respaldo:
```bash
python3 scripts/create_zip.py
```
El archivo comprimido generado se ubicará en: `public/proyecto-gregory-izquierdo.zip`.

### Paso 3: Despliegue en el Servidor / Hosting (Vite + Node / Express)
1. **Subir los archivos:** Carga los archivos del directorio `dist/` a tu servidor Web o hosting (Netlify, Vercel, Hostinger, Firebase Hosting, o VPS).
2. **Variables de Entorno (.env):** Asegúrate de mantener configuradas las variables de entorno oficiales:
   * `VITE_BCV_RATE`: Tasa predeterminada del Dólar BCV.
   * `VITE_OFFICIAL_DOMINIO`: Dominio verificado del proyecto.
3. **Reinicio del Servicio:** Si utilizas Node.js Express para el backend proxy, ejecuta:
   ```bash
   npm run start
   ```

### Paso 4: Notificación y Sincronización Post-Actualización
* Ingresa al panel de administración en el navegador.
* Dirígete a la pestaña **Google Drive & Sheets** y presiona **"Sincronizar Todos los Datos"** para asegurar que el nuevo esquema de base de datos se conecte perfectamente con tus plantillas activas.

---
*Documento oficial de arquitectura e infraestructura — Proyecto Gregori Izquierdo 2026.*
