import { create } from 'zustand';
import { 
  Product, Order, CustomerUser, FranchiseTenant, ExpenseItem, 
  PaymentMethod, SupplierPurchase, AccountingEntry, AppBrandingConfig, Invoice 
} from '../types';
import { 
  INITIAL_PRODUCTS, INITIAL_PAYMENT_METHODS, INITIAL_CUSTOMERS 
} from '../data/defaultCatalog';

interface AppState {
  // Financial State
  bankBalances: Record<string, { balanceUsd: number; balanceBs: number }>;
  accountsReceivable: any[];
  accountsPayable: any[];
  purchases: SupplierPurchase[];
  accountingEntries: AccountingEntry[];
  
  // Core Entities
  products: Product[];
  orders: Order[];
  customers: CustomerUser[];
  franchises: FranchiseTenant[];
  expenses: ExpenseItem[];
  paymentMethods: PaymentMethod[];
  branding: AppBrandingConfig;
  invoices: Invoice[];
  
  // Actions
  setBankBalances: (balances: Record<string, { balanceUsd: number; balanceBs: number }>) => void;
  setAccountsReceivable: (cxc: any[]) => void;
  setAccountsPayable: (cxp: any[]) => void;
  setProducts: (products: Product[] | ((prev: Product[]) => Product[])) => void;
  setOrders: (orders: Order[] | ((prev: Order[]) => Order[])) => void;
  setCustomers: (customers: CustomerUser[] | ((prev: CustomerUser[]) => CustomerUser[])) => void;
  setFranchises: (franchises: FranchiseTenant[] | ((prev: FranchiseTenant[]) => FranchiseTenant[])) => void;
  setExpenses: (expenses: ExpenseItem[] | ((prev: ExpenseItem[]) => ExpenseItem[])) => void;
  setPaymentMethods: (methods: PaymentMethod[] | ((prev: PaymentMethod[]) => PaymentMethod[])) => void;
  setInvoices: (invoices: Invoice[] | ((prev: Invoice[]) => Invoice[])) => void;
  setPurchases: (purchases: SupplierPurchase[] | ((prev: SupplierPurchase[]) => SupplierPurchase[])) => void;
  setBranding: (branding: AppBrandingConfig | ((prev: AppBrandingConfig) => AppBrandingConfig)) => void;

  
  // Atomic Action: Register Purchase
  addPurchase: (purchase: SupplierPurchase, paymentAccountId?: string) => void;
}

// Lectura segura desde localStorage (sin registros de ejemplo)
const load = <T,>(key: string, fallback: T): T => {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
};

export const useAppStore = create<AppState>((set, get) => ({
  // Initialize from localStorage if available, or default data
  bankBalances: load('maxter_initial_bank_balances', {}),
  accountsReceivable: load('maxter_accounts_receivable', []),
  accountsPayable: load('maxter_accounts_payable', []),
  purchases: load<SupplierPurchase[]>('streamsync_purchases_v2', []),
  accountingEntries: [],
  products: load<Product[]>('streamsync_products_v2', INITIAL_PRODUCTS),
  orders: load<Order[]>('streamsync_orders_v2', []),
  customers: load<CustomerUser[]>('streamsync_customers_v2', INITIAL_CUSTOMERS),
  franchises: load<FranchiseTenant[]>('streamsync_franchises_v1', []),
  expenses: load<ExpenseItem[]>('gi_expenses_list_2026', []),
  paymentMethods: load<PaymentMethod[]>('streamsync_methods_v2', INITIAL_PAYMENT_METHODS),
  invoices: load<Invoice[]>('streamsync_invoices_v1', []),
  branding: load<AppBrandingConfig>('streamsync_branding_v1', {
      projectName: 'Gregory Izquierdo Streaming',
      rif: '',
      slogan: 'Tu plataforma de streaming de alta gama 24/7',
      primaryColor: '#6366f1',
      secondaryColor: '#8b5cf6',
      fontFamily: 'Plus Jakarta Sans',
      heroTitle: 'Tus suscripciones de streaming favoritas con un',
      heroTitleGradient: 'diseño claro y precio justo',
      heroSubtitle: 'Perfiles privados con PIN y cuentas completas en 4K Ultra HD. Paga con Pago Móvil a tasa oficial BCV, Binance Pay, Zelle, Airtm, Pichincha, Zinli o saldo GRPAY.',
      heroBadgeText: 'Entrega Inmediata & Garantía Total de Duración',
      heroFontSize: '3xl',
      heroFontFamily: 'Plus Jakarta Sans',
      heroAlignment: 'center',
      bannerPlacement: 'below_hero',
      bannerThickness: 'normal',
      bannerMessage: '¡Bienvenidos a nuestra plataforma de streaming oficial! Soporte 24/7 y recargas inmediatas vía WhatsApp y Telegram.',
      bannerPhone: '04241983648 / +584241983648',
      bannerEmail: 'emprendimientogregoryizquierdo@gmail.com',
      cardRadius: 'rounded-2xl',
      containerMaxWidth: 'max-w-7xl'
  } as AppBrandingConfig),

  setBankBalances: (bankBalances) => {
    localStorage.setItem('maxter_initial_bank_balances', JSON.stringify(bankBalances));
    set({ bankBalances });
  },
  setAccountsReceivable: (accountsReceivable) => {
    localStorage.setItem('maxter_accounts_receivable', JSON.stringify(accountsReceivable));
    set({ accountsReceivable });
  },
  setAccountsPayable: (accountsPayable) => {
    localStorage.setItem('maxter_accounts_payable', JSON.stringify(accountsPayable));
    set({ accountsPayable });
  },
  setProducts: (val) => {
    set((state) => {
      const products = typeof val === 'function' ? (val as any)(state.products) : val;
      localStorage.setItem('streamsync_products_v2', JSON.stringify(products));
      return { products };
    });
  },
  setOrders: (val) => {
    set((state) => {
      const orders = typeof val === 'function' ? (val as any)(state.orders) : val;
      localStorage.setItem('streamsync_orders_v2', JSON.stringify(orders));
      return { orders };
    });
  },
  setCustomers: (val) => {
    set((state) => {
      const customers = typeof val === 'function' ? (val as any)(state.customers) : val;
      localStorage.setItem('streamsync_customers_v2', JSON.stringify(customers));
      return { customers };
    });
  },
  setFranchises: (val) => {
    set((state) => {
      const franchises = typeof val === 'function' ? (val as any)(state.franchises) : val;
      localStorage.setItem('streamsync_franchises_v1', JSON.stringify(franchises));
      return { franchises };
    });
  },
  setExpenses: (val) => {
    set((state) => {
      const expenses = typeof val === 'function' ? (val as any)(state.expenses) : val;
      localStorage.setItem('gi_expenses_list_2026', JSON.stringify(expenses));
      return { expenses };
    });
  },
  setPaymentMethods: (val) => {
    set((state) => {
      const paymentMethods = typeof val === 'function' ? (val as any)(state.paymentMethods) : val;
      localStorage.setItem('streamsync_methods_v2', JSON.stringify(paymentMethods));
      return { paymentMethods };
    });
  },
  setInvoices: (val) => {
    set((state) => {
      const invoices = typeof val === 'function' ? (val as any)(state.invoices) : val;
      localStorage.setItem('streamsync_invoices_v1', JSON.stringify(invoices));
      return { invoices };
    });
  },
  setPurchases: (val) => {
    set((state) => {
      const purchases = typeof val === 'function' ? (val as any)(state.purchases) : val;
      localStorage.setItem('streamsync_purchases_v2', JSON.stringify(purchases));
      return { purchases };
    });
  },
  setBranding: (val) => {
    set((state) => {
      const branding = typeof val === 'function' ? (val as any)(state.branding) : val;
      localStorage.setItem('streamsync_branding_v1', JSON.stringify(branding));
      return { branding };
    });
  },

  // Atomic Action: Register Purchase
  addPurchase: (purchase, paymentAccountId) => {
    const state = get();
    const updatedPurchases = [...state.purchases, purchase];
    localStorage.setItem('streamsync_purchases_v2', JSON.stringify(updatedPurchases));

    const newEntry: AccountingEntry = {
      id: `ENT-${Date.now()}`,
      entryNumber: state.accountingEntries.length + 1,
      date: new Date().toISOString(),
      concept: `Compra a ${purchase.supplierName} - ${purchase.platform}`,
      debitAccount: 'Costos de Venta',
      debitAmount: purchase.costUsd,
      creditAccount: paymentAccountId || 'Cuentas por Pagar',
      creditAmount: purchase.costUsd,
      sourceType: 'purchase',
      referenceId: purchase.id
    };

    let updatedBalances = { ...state.bankBalances };
    if (paymentAccountId && updatedBalances[paymentAccountId]) {
        updatedBalances[paymentAccountId].balanceUsd -= purchase.costUsd;
        localStorage.setItem('maxter_initial_bank_balances', JSON.stringify(updatedBalances));
    }

    set({ 
        purchases: updatedPurchases, 
        accountingEntries: [...state.accountingEntries, newEntry],
        bankBalances: updatedBalances
    });
  },
}));
